var path = require('path')
  , mayonnaise = require('../')
  , server = require('http').createServer()
  , path = require('path')

var specs = [
  {
    cwd: path.join(__dirname, 'public'),
    globs: ['**/*']
  }
];
var middleware = mayonnaise(specs).middleware('static');

server.on('request', function (req, res) {
  middleware(req, res, function (err) {
    res.writeHead(404, {'Content-Type': 'text/plain'});
    res.end('Path not found');
  });
});

server.listen(3000, function () {
  console.log('listening on http://localhost:' + server.address().port + '/');
});
